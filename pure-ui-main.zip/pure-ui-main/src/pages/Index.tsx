import { FileExplorer } from "@/components/FileExplorer";

const Index = () => {
  return <FileExplorer />;
};

export default Index;
